﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prvi_projekat
{
    [Serializable]
    class Korisnik
    {
        protected string lozinka;
        protected string korIme;

        public Korisnik(string korIme, string lozinka)
        {
            this.KorIme = korIme;
            this.Lozinka = lozinka;
        }
        public string KorIme { get => korIme; set => korIme = value; }
        public string Lozinka { get => lozinka; set => lozinka = value; }
    }
}
