﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prvi_projekat
{
    [Serializable]
    class Film
    {
        private int id, duzina, granicaGod;
        private string naziv, zanr;

        public Film(int id, int duzina, int granicaGod, string naziv, string zanr)
        {
            this.Id = id;
            this.Duzina = duzina;
            this.GranicaGod = granicaGod;
            this.Naziv = naziv;
            this.Zanr = zanr;
        }

        public int Id { get => id; set => id = value; }
        public int Duzina { get => duzina; set => duzina = value; }
        public int GranicaGod { get => granicaGod; set => granicaGod = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public string Zanr { get => zanr; set => zanr = value; }

        public override string ToString()
        {
            return $"Naziv filma: {naziv}; Zanr: {zanr}; Duzina trajanja: {duzina}; Granica godina: {granicaGod}";
        }
    }
}
