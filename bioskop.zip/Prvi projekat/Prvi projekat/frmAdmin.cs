﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prvi_projekat
{
    public partial class frmAdmin : Form
    {
        FileStream fs;
        BinaryFormatter bf;

        List<Kupac> kupci;
        List<Rezervacije> rez;

        string fajlKupci = "kupci.bin";
        string fajlRez = "rezervacije.bin";
        public frmAdmin()
        {
            InitializeComponent();

            if (File.Exists(fajlKupci))
            {
                fs = File.OpenRead(fajlKupci);
                bf = new BinaryFormatter();
                kupci = bf.Deserialize(fs) as List<Kupac>;
                fs.Close();
            }


            if (File.Exists(fajlRez))
            {
                fs = File.OpenRead(fajlRez);
                rez = bf.Deserialize(fs) as List<Rezervacije>;
                fs.Close();
            }
            else
                rez = new List<Rezervacije>();
        }

        private void frmAdmin_Load(object sender, EventArgs e)
        {
            cbKorisnici.DataSource = kupci;
        }

        private void btnUpis_Click(object sender, EventArgs e)
        {
            frmUpis upis = new frmUpis();
            upis.Show();
        }

        private void btnAzuriranje_Click(object sender, EventArgs e)
        {
            frmIzmena izmena = new frmIzmena();
            izmena.Show();
        }

        private void btnBrisanje_Click(object sender, EventArgs e)
        {
            frmBrisanje brisanje = new frmBrisanje();
            brisanje.Show();
        }

        private void cbKorisnici_SelectedIndexChanged(object sender, EventArgs e)
        {
            lsRez.Items.Clear();
            Kupac kupac = cbKorisnici.SelectedItem as Kupac;
            foreach (Rezervacije r in rez)
            {
                if (r.IdKupca == kupac.Id)
                    lsRez.Items.Add(r);
            }
        }
    }
}
