﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prvi_projekat
{
    public partial class frmIzmena : Form
    {
        FileStream fs;
        BinaryFormatter bf = new BinaryFormatter();

        List<Kupac> kupci;
        List<Film> filmovi;
        List<Sala> sale;
        List<Projekcija> projekcije;
        List<Rezervacije> rezervacije;

        string fajlFilmovi = "filmovi.bin";
        string fajlKupci = "kupci.bin";
        string fajlSale = "sale.bin";
        string fajlProj = "projekcije.bin";
        string fajlRez = "rezervacije.bin";
        public frmIzmena()
        {
            InitializeComponent();
            filmovi = new List<Film>();
            sale = new List<Sala>();
            projekcije = new List<Projekcija>();
            rezervacije = new List<Rezervacije>();

            if (File.Exists(fajlKupci))
            {
                fs = File.OpenRead(fajlKupci);
                kupci = bf.Deserialize(fs) as List<Kupac>;
                fs.Close();
            }
            else
                kupci = new List<Kupac>();

            dtProj.MinDate = DateTime.Today;

            foreach (Kupac k in kupci)
            {
                cbKorisnik.Items.Add(k);
                cbIdKupca.Items.Add(k.Id);
            }

            if (File.Exists(fajlFilmovi))
            {
                fs = File.OpenRead(fajlFilmovi);
                filmovi = bf.Deserialize(fs) as List<Film>;

                fs.Close();
                foreach (Film film in filmovi)
                {
                    cbFilm.Items.Add(film);
                    cbProjFilm.Items.Add(film);
                }
            }
            if (File.Exists(fajlSale))
            {
                fs = File.OpenRead(fajlSale);
                sale = bf.Deserialize(fs) as List<Sala>;

                fs.Close();
                foreach (Sala sala in sale)
                {
                    cbSala.Items.Add(sala);
                    cbProjSala.Items.Add(sala);
                }
            }
            if (File.Exists(fajlProj))
            {
                fs = File.OpenRead(fajlProj);
                projekcije = bf.Deserialize(fs) as List<Projekcija>;

                fs.Close();
                foreach (Projekcija proj in projekcije)
                {
                    cbProjekcija.Items.Add(proj);
                    cbIdProj.Items.Add(proj.Id);
                }
            }
            if (File.Exists(fajlRez))
            {
                fs = File.OpenRead(fajlRez);
                rezervacije = bf.Deserialize(fs) as List<Rezervacije>;

                fs.Close();
                foreach (Rezervacije rez in rezervacije)
                    cbRez.Items.Add(rez);
            }
        }

        private void btnIzmeniFilm_Click(object sender, EventArgs e)
        {
            int duzina, granica;
            if (cbFilm.SelectedItem == null)
            {
                MessageBox.Show("Niste odabrali film");
                return;
            }
            else if (txtNaziv.Text.Trim().Length == 0 || txtZanr.Text.Trim().Length == 0 || txtDuzina.Text.Trim().Length == 0 || txtGranica.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste popunili neko od polja za film");
                return;
            }
            else if (!int.TryParse(txtDuzina.Text, out duzina) || !int.TryParse(txtGranica.Text, out granica))
            {
                MessageBox.Show("Niste uneli broj za duzinu ili granicu");
                return;
            }
            for (int i = 0; i < filmovi.Count; i++)
            {
                if (cbFilm.SelectedItem as Film == filmovi[i])
                {
                    filmovi[i].Naziv = txtNaziv.Text;
                    filmovi[i].Zanr = txtZanr.Text;
                    filmovi[i].Duzina = duzina;
                    filmovi[i].GranicaGod = granica;

                    MessageBox.Show("Podatci su uspesno ste azurirani!");
                    cbFilm.Items.Clear();
                    foreach (Film film in filmovi)
                        cbFilm.Items.Add(film);
                    break;
                }
            }
        }

        private void cbFilm_SelectedIndexChanged(object sender, EventArgs e)
        {
            Film film = cbFilm.SelectedItem as Film;
            txtNaziv.Text = film.Naziv;
            txtZanr.Text = film.Zanr;
            txtDuzina.Text = film.Duzina.ToString();
            txtGranica.Text = film.GranicaGod.ToString();
        }

        private void cbProjekcija_SelectedIndexChanged(object sender, EventArgs e)
        {
            Projekcija proj = cbProjekcija.SelectedItem as Projekcija;
            for (int i = 0; i < cbProjFilm.Items.Count; i++)
            {
                cbProjFilm.SelectedIndex = i;
                if ((cbProjFilm.SelectedItem as Film).Id==proj.Film.Id)
                    break;
            }
            for (int i = 0; i < cbProjSala.Items.Count; i++)
            {
                cbProjSala.SelectedIndex = i;
                if ((cbProjSala.SelectedItem as Sala).BrSale == proj.Sala.BrSale)
                    break;
            }
            dtProj.Value = proj.DatumProj;
            dtVrPoc.Value = proj.VremePocetka;
            txtCena.Text = proj.CenaKarte.ToString();
        }

        private void cbSala_SelectedIndexChanged(object sender, EventArgs e)
        {
            Sala sala = cbSala.SelectedItem as Sala;
            txtBrSale.Text = sala.BrSale.ToString();
            txtBrSedista.Text = sala.BrSedista.ToString();
        }
        private void cbSala_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            Sala sala = cbSala.SelectedItem as Sala;
            txtBrSale.Text = sala.BrSale.ToString();
            txtBrSedista.Text = sala.BrSedista.ToString();
        }
        private void cbRez_SelectedIndexChanged(object sender, EventArgs e)
        {
            Rezervacije rez = cbRez.SelectedItem as Rezervacije;
            for (int i = 0; i < cbIdProj.Items.Count; i++)
            {
                cbIdProj.SelectedIndex = i;
                if (rez.IdProj == (int)cbIdProj.SelectedItem)
                    break;
            }
            for (int i = 0; i < cbIdKupca.Items.Count; i++)
            {
                cbIdKupca.SelectedIndex = i;
                if (rez.IdKupca == (int)cbIdKupca.SelectedItem)
                    break;
            }
            txtBrMesta.Text = rez.BrMesta.ToString();
            txtUkCena.Text = rez.UkCena.ToString();
        }

        private void cbKorisnik_SelectedIndexChanged(object sender, EventArgs e)
        {
            Kupac kupac = cbKorisnik.SelectedItem as Kupac;
            txtKorIme.Text = kupac.KorIme;
            txtLoz.Text = kupac.Lozinka;
            txtImeKor.Text = kupac.Ime;
            txtPrezKor.Text = kupac.Prezime;
            if (kupac.Pol == "muski")
                cbPolKor.SelectedIndex = 0;
            else
                cbPolKor.SelectedIndex = 1;
            txtTelKor.Text = kupac.Telefon;
            dtDatumRodjKor.Value = kupac.DatRodj;
        }

        private void btnMenjajProj_Click(object sender, EventArgs e)
        {
            int cena;
            if (cbProjekcija.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali projekciju");
                return;
            }
            else if (cbProjFilm.SelectedItem == null || cbProjSala.SelectedItem == null || txtCena.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste uneli sve informacije za projekciju");
                return;
            }
            else if (!int.TryParse(txtCena.Text, out cena))
            {
                MessageBox.Show("Niste uneli broj za cenu");
                return;
            }
            for (int i = 0; i < projekcije.Count; i++)
            {
                if (cbProjekcija.SelectedItem as Projekcija == projekcije[i])
                {
                    projekcije[i].Film = cbProjFilm.SelectedItem as Film;
                    projekcije[i].Sala = cbProjSala.SelectedItem as Sala;
                    projekcije[i].DatumProj = dtProj.Value;
                    projekcije[i].VremePocetka = dtVrPoc.Value;
                    projekcije[i].CenaKarte = cena;

                    MessageBox.Show("Uspesno ste azurirali podatke");
                    cbProjekcija.Items.Clear();
                    foreach (Projekcija proj in projekcije)
                        cbProjekcija.Items.Add(proj);
                    return;
                }
            }
        }

        private void btnIzmeniSalu_Click(object sender, EventArgs e)
        {
            int brSale, brSedista;
            if (cbSala.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali salu");
                return;
            }
            else if (txtBrSale.Text.Trim().Length == 0 || txtBrSedista.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste uneli sve informacije za salu");
                return;
            }
            else if (!int.TryParse(txtBrSale.Text, out brSale) || !int.TryParse(txtBrSedista.Text, out brSedista))
            {
                MessageBox.Show("Niste uneli broj za broj sale ili sedista");
                return;
            }
            for (int i = 0; i < sale.Count; i++)
            {
                if (cbSala.SelectedItem as Sala == sale[i])
                {
                    sale[i].BrSale = brSale;
                    sale[i].BrSedista = brSedista;

                    MessageBox.Show("Uspesno ste azurirali podatke");
                    cbSala.Items.Clear();
                    foreach (Sala sala in sale)
                        cbSala.Items.Add(sala);
                    return;
                }
            }
        }

        private void btnIzmeniRez_Click(object sender, EventArgs e)
        {
            int brMesta;
            if (cbRez.SelectedItem == null)
            {
                MessageBox.Show("Niste odabrali rezervaciju");
                return;
            }
            else if (cbIdProj.SelectedItem == null || cbIdKupca.SelectedItem == null || txtBrMesta.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste uneli sve informacije za rezervaciju");
                return;
            }
            else if (!int.TryParse(txtBrMesta.Text, out brMesta))
            {
                MessageBox.Show("Niste uneli broj za broj mesta");
                return;
            }
            for (int i = 0; i < rezervacije.Count; i++)
            {
                if (rezervacije[i] == cbRez.SelectedItem as Rezervacije)
                {
                    for (int j = 0; j < projekcije.Count; j++)
                    {
                        if (projekcije[j].Id == rezervacije[i].IdProj)
                        {
                            if (rezervacije[i].BrMesta < brMesta)
                            {
                                if (projekcije[j].SlobodnoMesta < Math.Abs(rezervacije[i].BrMesta - brMesta))
                                {
                                    MessageBox.Show("Nema dovoljno slobodnih mesta u sali. Broj slobodnih mesta je" + projekcije[j].SlobodnoMesta);
                                    return;
                                }
                                projekcije[j].SlobodnoMesta -= Math.Abs(rezervacije[i].BrMesta - brMesta);
                            }
                            else if (rezervacije[i].BrMesta > brMesta)
                                projekcije[j].SlobodnoMesta += Math.Abs(rezervacije[i].BrMesta - brMesta);
                        }
                    }

                    rezervacije[i].IdProj = (int)cbIdProj.SelectedItem;
                    rezervacije[i].IdKupca = (int)cbIdKupca.SelectedItem;

                    rezervacije[i].UkCena = int.Parse(txtUkCena.Text);

                    rezervacije[i].BrMesta = brMesta;
                    MessageBox.Show("Uspesno ste azurirali podatke");

                    cbProjekcija.Items.Clear();
                    foreach (Projekcija proj in projekcije)
                        cbProjekcija.Items.Add(proj);

                    cbRez.Items.Clear();
                    foreach (Rezervacije rez in rezervacije)
                        cbRez.Items.Add(rez);
                    return;
                }
            }
        }

        private void btnIzmeniKorisnika_Click(object sender, EventArgs e)
        {
            if (cbKorisnik.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali korisnika");
                return;
            }
            else if (txtKorIme.Text.Trim().Length == 0 || txtLoz.Text.Trim().Length == 0 || txtImeKor.Text.Trim().Length == 0 || txtPrezKor.Text.Trim().Length == 0 || cbPolKor.SelectedItem == null || txtTelKor.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste uneli sve informacije vezane za korisnika");
                return;
            }
            for (int i = 0; i < kupci.Count; i++)
            {
                if (kupci[i] == cbKorisnik.SelectedItem as Kupac)
                {
                    kupci[i].KorIme = txtKorIme.Text;
                    kupci[i].Lozinka = txtLoz.Text;
                    kupci[i].Ime = txtImeKor.Text;
                    kupci[i].Prezime = txtPrezKor.Text;
                    kupci[i].Pol = cbPolKor.SelectedItem.ToString();
                    kupci[i].Telefon = txtTelKor.Text;
                    kupci[i].DatRodj = dtDatumRodjKor.Value;

                    MessageBox.Show("Uspesno ste azurirali podatke");
                    cbKorisnik.Items.Clear();
                    foreach (Kupac kupac in kupci)
                        cbKorisnik.Items.Add(kupac);
                    return;
                }
            }
        }

        private void frmIzmena_FormClosing(object sender, FormClosingEventArgs e)
        {
            fs = File.OpenWrite(fajlKupci);
            bf.Serialize(fs, kupci);
            fs.Close();

            fs = File.OpenWrite(fajlRez);
            bf.Serialize(fs, rezervacije);
            fs.Close();

            fs = File.OpenWrite(fajlProj);
            bf.Serialize(fs, projekcije);
            fs.Close();

            fs = File.OpenWrite(fajlSale);
            bf.Serialize(fs, sale);
            fs.Close();

            fs = File.OpenWrite(fajlFilmovi);
            bf.Serialize(fs, filmovi);
            fs.Close();
        }

        private void txtBrMesta_TextChanged(object sender, EventArgs e)
        {
            int brMesta;
            if (!int.TryParse(txtBrMesta.Text, out brMesta))
                return;
            if (cbIdProj.SelectedItem == null)
                return;
            foreach (Projekcija proj in projekcije)
                if (proj.Id == (int)cbIdProj.SelectedItem)
                {
                    txtUkCena.Text = (proj.CenaKarte * brMesta).ToString();
                    break;
                }
        }
    }
}
