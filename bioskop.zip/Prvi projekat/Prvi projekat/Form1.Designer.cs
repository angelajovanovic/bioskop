﻿namespace Prvi_projekat
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReg = new System.Windows.Forms.Button();
            this.rbZ = new System.Windows.Forms.RadioButton();
            this.rbM = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPrez = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtIme = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPotLoz = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtRegLoz = new System.Windows.Forms.TextBox();
            this.txtRegKorIme = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnUloguj = new System.Windows.Forms.Button();
            this.txtPrijLoz = new System.Windows.Forms.TextBox();
            this.txtPrijKorIme = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtDatRodj = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // btnReg
            // 
            this.btnReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReg.Location = new System.Drawing.Point(433, 380);
            this.btnReg.Name = "btnReg";
            this.btnReg.Size = new System.Drawing.Size(235, 31);
            this.btnReg.TabIndex = 51;
            this.btnReg.Text = "Registruj se";
            this.btnReg.UseVisualStyleBackColor = true;
            this.btnReg.Click += new System.EventHandler(this.btnReg_Click);
            // 
            // rbZ
            // 
            this.rbZ.AutoSize = true;
            this.rbZ.Location = new System.Drawing.Point(535, 344);
            this.rbZ.Name = "rbZ";
            this.rbZ.Size = new System.Drawing.Size(61, 17);
            this.rbZ.TabIndex = 50;
            this.rbZ.TabStop = true;
            this.rbZ.Text = "Zensko";
            this.rbZ.UseVisualStyleBackColor = true;
            // 
            // rbM
            // 
            this.rbM.AutoSize = true;
            this.rbM.Location = new System.Drawing.Point(535, 321);
            this.rbM.Name = "rbM";
            this.rbM.Size = new System.Drawing.Size(57, 17);
            this.rbM.TabIndex = 49;
            this.rbM.Text = "Musko";
            this.rbM.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(430, 326);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 16);
            this.label13.TabIndex = 48;
            this.label13.Text = "Pol:";
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(535, 294);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(133, 20);
            this.txtTel.TabIndex = 47;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(430, 298);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 16);
            this.label12.TabIndex = 46;
            this.label12.Text = "Telefon:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(430, 272);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 16);
            this.label11.TabIndex = 45;
            this.label11.Text = "Datum rodjenja:";
            // 
            // txtPrez
            // 
            this.txtPrez.Location = new System.Drawing.Point(535, 241);
            this.txtPrez.Name = "txtPrez";
            this.txtPrez.Size = new System.Drawing.Size(133, 20);
            this.txtPrez.TabIndex = 43;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(430, 241);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 16);
            this.label9.TabIndex = 42;
            this.label9.Text = "Prezime:";
            // 
            // txtIme
            // 
            this.txtIme.Location = new System.Drawing.Point(535, 215);
            this.txtIme.Name = "txtIme";
            this.txtIme.Size = new System.Drawing.Size(133, 20);
            this.txtIme.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(430, 215);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 16);
            this.label10.TabIndex = 40;
            this.label10.Text = "Ime:";
            // 
            // txtPotLoz
            // 
            this.txtPotLoz.Location = new System.Drawing.Point(535, 189);
            this.txtPotLoz.Name = "txtPotLoz";
            this.txtPotLoz.PasswordChar = '*';
            this.txtPotLoz.Size = new System.Drawing.Size(133, 20);
            this.txtPotLoz.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(430, 189);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 16);
            this.label8.TabIndex = 38;
            this.label8.Text = "Potvrda lozinke:";
            // 
            // txtRegLoz
            // 
            this.txtRegLoz.Location = new System.Drawing.Point(535, 163);
            this.txtRegLoz.Name = "txtRegLoz";
            this.txtRegLoz.PasswordChar = '*';
            this.txtRegLoz.Size = new System.Drawing.Size(133, 20);
            this.txtRegLoz.TabIndex = 37;
            // 
            // txtRegKorIme
            // 
            this.txtRegKorIme.Location = new System.Drawing.Point(535, 136);
            this.txtRegKorIme.Name = "txtRegKorIme";
            this.txtRegKorIme.Size = new System.Drawing.Size(133, 20);
            this.txtRegKorIme.TabIndex = 36;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(430, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 16);
            this.label6.TabIndex = 35;
            this.label6.Text = "Lozinka:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(430, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 16);
            this.label7.TabIndex = 34;
            this.label7.Text = "Korisnicko ime:";
            // 
            // btnUloguj
            // 
            this.btnUloguj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUloguj.Location = new System.Drawing.Point(69, 197);
            this.btnUloguj.Name = "btnUloguj";
            this.btnUloguj.Size = new System.Drawing.Size(235, 34);
            this.btnUloguj.TabIndex = 33;
            this.btnUloguj.Text = "Uloguj se";
            this.btnUloguj.UseVisualStyleBackColor = true;
            this.btnUloguj.Click += new System.EventHandler(this.btnUloguj_Click);
            // 
            // txtPrijLoz
            // 
            this.txtPrijLoz.Location = new System.Drawing.Point(171, 162);
            this.txtPrijLoz.Name = "txtPrijLoz";
            this.txtPrijLoz.PasswordChar = '*';
            this.txtPrijLoz.Size = new System.Drawing.Size(133, 20);
            this.txtPrijLoz.TabIndex = 32;
            // 
            // txtPrijKorIme
            // 
            this.txtPrijKorIme.Location = new System.Drawing.Point(171, 135);
            this.txtPrijKorIme.Name = "txtPrijKorIme";
            this.txtPrijKorIme.Size = new System.Drawing.Size(133, 20);
            this.txtPrijKorIme.TabIndex = 31;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(66, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 16);
            this.label5.TabIndex = 30;
            this.label5.Text = "Lozinka:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(66, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 16);
            this.label4.TabIndex = 29;
            this.label4.Text = "Korisnicko ime:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(496, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 25);
            this.label3.TabIndex = 28;
            this.label3.Text = "Registracija:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(126, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 25);
            this.label2.TabIndex = 27;
            this.label2.Text = "Prijava:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(273, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 39);
            this.label1.TabIndex = 26;
            this.label1.Text = "Prijavite se";
            // 
            // dtDatRodj
            // 
            this.dtDatRodj.Location = new System.Drawing.Point(535, 272);
            this.dtDatRodj.Name = "dtDatRodj";
            this.dtDatRodj.Size = new System.Drawing.Size(133, 20);
            this.dtDatRodj.TabIndex = 52;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 450);
            this.Controls.Add(this.dtDatRodj);
            this.Controls.Add(this.btnReg);
            this.Controls.Add(this.rbZ);
            this.Controls.Add(this.rbM);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtTel);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtPrez);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtIme);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtPotLoz);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtRegLoz);
            this.Controls.Add(this.txtRegKorIme);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnUloguj);
            this.Controls.Add(this.txtPrijLoz);
            this.Controls.Add(this.txtPrijKorIme);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReg;
        private System.Windows.Forms.RadioButton rbZ;
        private System.Windows.Forms.RadioButton rbM;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPrez;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtIme;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtPotLoz;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtRegLoz;
        private System.Windows.Forms.TextBox txtRegKorIme;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnUloguj;
        private System.Windows.Forms.TextBox txtPrijLoz;
        private System.Windows.Forms.TextBox txtPrijKorIme;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtDatRodj;
    }
}

