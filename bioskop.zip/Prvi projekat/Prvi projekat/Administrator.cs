﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prvi_projekat
{
    class Administrator:Korisnik
    {
        public Administrator() : base("andjela", "nrt7019")
        {
        }
    }
}
