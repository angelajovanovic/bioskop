﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prvi_projekat
{
    [Serializable]
    class Kupac:Korisnik
    {
        private int id;
        private string ime, prezime, pol, telefon;
        private DateTime datRodj;

        public Kupac(int id, string korIme, string lozinka, string ime, string prezime, string pol, string telefon, DateTime datRodj) : base(korIme, lozinka)
        {
            this.Ime = ime;
            this.Prezime = prezime;
            this.Pol = pol;
            this.Telefon = telefon;
            this.DatRodj = datRodj;
            this.id = id;
        }

        public int Id { get => id; set => id = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string Pol { get => pol; set => pol = value; }
        public string Telefon { get => telefon; set => telefon = value; }
        public DateTime DatRodj { get => datRodj; set => datRodj = value; }

        public override string ToString()
        {
            return $"ID: {id}; Ime: {ime}; Prezime: {prezime}; Pol: {pol}; Telefon: {telefon}; Datum rodjenja: {datRodj}";
        }
    }
}
