﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prvi_projekat
{
    public partial class frmKupacPoc : Form
    {
        string fajlKupci = "kupci.bin";
        string fajlRezervacije = "rezervacije.bin";
        string fajlProj = "projekcije.bin";

        List<Kupac> kupci;
        List<Rezervacije> rezervacije;
        List<Projekcija> projekcije;

        FileStream fs;
        BinaryFormatter bf = new BinaryFormatter();
        int idKor;
        public frmKupacPoc(int idKor)
        {
            InitializeComponent();

            if (File.Exists(fajlKupci))
            {
                fs = File.OpenRead(fajlKupci);
                kupci = bf.Deserialize(fs) as List<Kupac>;
                fs.Close();
            }
            else
                kupci = new List<Kupac>();

            if (File.Exists(fajlRezervacije))
            {
                fs = File.OpenRead(fajlRezervacije);
                rezervacije = bf.Deserialize(fs) as List<Rezervacije>;
                fs.Close();
            }
            else
                rezervacije = new List<Rezervacije>();

            if (File.Exists(fajlProj))
            {
                fs = File.OpenRead(fajlProj);
                projekcije = bf.Deserialize(fs) as List<Projekcija>;
                fs.Close();
            }
            else
                projekcije = new List<Projekcija>();

            foreach (Kupac kupac in kupci)
                if (kupac.Id == idKor)
                {
                    lblKor.Text = $"Prijavljeni korisnik: {kupac.KorIme}";
                    break;
                }
            this.idKor = idKor;


            foreach (Rezervacije rezervacija in rezervacije)
                if (idKor == rezervacija.IdKupca)
                    lstRez.Items.Add(rezervacija);
        }

        private void btnNovaRez_Click(object sender, EventArgs e)
        {
            frmKupac formaKupac = new frmKupac(idKor);
            formaKupac.Show();
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            if (lstRez.SelectedItem == null)
            {
                MessageBox.Show("Nemate izabranu rezervaciju");
                return;
            }
            for (int i = 0; i < rezervacije.Count; i++)
            {
                if (lstRez.SelectedItem as Rezervacije == rezervacije[i])
                {
                    for (int j = 0; j < projekcije.Count; j++)
                    {
                        if (rezervacije[i].IdProj == projekcije[j].Id)
                        {
                            projekcije[j].SlobodnoMesta += rezervacije[i].BrMesta;
                        }
                    }
                    rezervacije.RemoveAt(i);

                    fs = File.OpenWrite(fajlRezervacije);
                    bf.Serialize(fs, rezervacije);
                    fs.Close();

                    fs = File.OpenWrite(fajlProj);
                    bf.Serialize(fs, projekcije);
                    fs.Close();

                    IzmeniListu();

                    MessageBox.Show("Uspesno ste obrisali rezervaciju");
                    return;
                }
            }
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            if (lstRez.SelectedItem == null)
            {
                MessageBox.Show("Niste odabrali rezervaciju");
                return;
            }
            else if (numBrMesta.Value == 0)
            {
                MessageBox.Show("Molimo unesite pozitivan broj mesta");
                return;
            }
            for (int i = 0; i < rezervacije.Count; i++)
            {
                if (lstRez.SelectedItem as Rezervacije == rezervacije[i])
                {
                    for (int j = 0; j < projekcije.Count; j++)
                    {
                        if (projekcije[j].Id == rezervacije[i].IdProj)
                        {
                            if (rezervacije[i].BrMesta < numBrMesta.Value)
                            {
                                if (projekcije[j].SlobodnoMesta < Math.Abs(rezervacije[i].BrMesta - numBrMesta.Value))
                                {
                                    MessageBox.Show("Nema dovoljno slobodnih mesta u sali. Broj slobodnih mesta je" + projekcije[j].SlobodnoMesta);
                                    return;
                                }
                                projekcije[j].SlobodnoMesta -= Math.Abs(rezervacije[i].BrMesta - int.Parse(numBrMesta.Value.ToString()));
                            }
                            else if (rezervacije[i].BrMesta > numBrMesta.Value)
                                projekcije[j].SlobodnoMesta += Math.Abs(rezervacije[i].BrMesta - int.Parse(numBrMesta.Value.ToString()));
                        }
                    }
                    rezervacije[i].BrMesta = int.Parse(numBrMesta.Value.ToString());
                    rezervacije[i].UkCena = int.Parse(txtUkCena.Text);

                    fs = File.OpenWrite(fajlRezervacije);
                    bf.Serialize(fs, rezervacije);
                    fs.Close();

                    IzmeniListu();

                    MessageBox.Show("Uspeno ste izmenili rezervaciju");
                    return;
                }
            }
        }

        private void numBrMesta_ValueChanged(object sender, EventArgs e)
        {
            if (lstRez.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali rezervaciju");
                numBrMesta.Value = 0;
                return;
            }
            foreach (Projekcija proj in projekcije)
            {
                if ((lstRez.SelectedItem as Rezervacije).IdProj == proj.Id)
                {
                    txtUkCena.Text = (proj.CenaKarte * numBrMesta.Value).ToString();
                    return;
                }
            }
        }

        private void lstRez_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstRez.SelectedItem == null)
                return;
            numBrMesta.Value = (lstRez.SelectedItem as Rezervacije).BrMesta;
        }
        public void IzmeniListu()
        {
            fs = File.OpenRead(fajlRezervacije);
            rezervacije = bf.Deserialize(fs) as List<Rezervacije>;
            fs.Close();

            lstRez.Items.Clear();
            foreach (Rezervacije rezervacija in rezervacije)
                if (idKor == rezervacija.IdKupca)
                    lstRez.Items.Add(rezervacija);
        }
    }
}
