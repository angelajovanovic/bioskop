﻿namespace Prvi_projekat
{
    partial class frmKupacPoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.txtUkCena = new System.Windows.Forms.TextBox();
            this.numBrMesta = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAzuriraj = new System.Windows.Forms.Button();
            this.btnObrisi = new System.Windows.Forms.Button();
            this.btnNovaRez = new System.Windows.Forms.Button();
            this.lstRez = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblKor = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numBrMesta)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(135, 386);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 20);
            this.label3.TabIndex = 19;
            this.label3.Text = "Ukupna cena:";
            // 
            // txtUkCena
            // 
            this.txtUkCena.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUkCena.Location = new System.Drawing.Point(139, 410);
            this.txtUkCena.Name = "txtUkCena";
            this.txtUkCena.ReadOnly = true;
            this.txtUkCena.Size = new System.Drawing.Size(134, 26);
            this.txtUkCena.TabIndex = 18;
            // 
            // numBrMesta
            // 
            this.numBrMesta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numBrMesta.Location = new System.Drawing.Point(13, 410);
            this.numBrMesta.Name = "numBrMesta";
            this.numBrMesta.Size = new System.Drawing.Size(120, 26);
            this.numBrMesta.TabIndex = 17;
            this.numBrMesta.ValueChanged += new System.EventHandler(this.numBrMesta_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 386);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 16;
            this.label1.Text = "Broj mesta:";
            // 
            // btnAzuriraj
            // 
            this.btnAzuriraj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAzuriraj.Location = new System.Drawing.Point(13, 442);
            this.btnAzuriraj.Name = "btnAzuriraj";
            this.btnAzuriraj.Size = new System.Drawing.Size(164, 42);
            this.btnAzuriraj.TabIndex = 15;
            this.btnAzuriraj.Text = "Azuriraj rezervaciju";
            this.btnAzuriraj.UseVisualStyleBackColor = true;
            this.btnAzuriraj.Click += new System.EventHandler(this.btnAzuriraj_Click);
            // 
            // btnObrisi
            // 
            this.btnObrisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnObrisi.Location = new System.Drawing.Point(13, 325);
            this.btnObrisi.Name = "btnObrisi";
            this.btnObrisi.Size = new System.Drawing.Size(164, 42);
            this.btnObrisi.TabIndex = 14;
            this.btnObrisi.Text = "Obrisi rezervaciju";
            this.btnObrisi.UseVisualStyleBackColor = true;
            this.btnObrisi.Click += new System.EventHandler(this.btnObrisi_Click);
            // 
            // btnNovaRez
            // 
            this.btnNovaRez.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovaRez.Location = new System.Drawing.Point(295, 325);
            this.btnNovaRez.Name = "btnNovaRez";
            this.btnNovaRez.Size = new System.Drawing.Size(217, 42);
            this.btnNovaRez.TabIndex = 13;
            this.btnNovaRez.Text = "Nova rezervacija";
            this.btnNovaRez.UseVisualStyleBackColor = true;
            this.btnNovaRez.Click += new System.EventHandler(this.btnNovaRez_Click);
            // 
            // lstRez
            // 
            this.lstRez.FormattingEnabled = true;
            this.lstRez.Location = new System.Drawing.Point(13, 68);
            this.lstRez.Name = "lstRez";
            this.lstRez.Size = new System.Drawing.Size(771, 251);
            this.lstRez.TabIndex = 12;
            this.lstRez.SelectedIndexChanged += new System.EventHandler(this.lstRez_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(289, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 31);
            this.label2.TabIndex = 11;
            this.label2.Text = "Vase rezervacije:";
            // 
            // lblKor
            // 
            this.lblKor.AutoSize = true;
            this.lblKor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKor.Location = new System.Drawing.Point(12, 9);
            this.lblKor.Name = "lblKor";
            this.lblKor.Size = new System.Drawing.Size(42, 20);
            this.lblKor.TabIndex = 10;
            this.lblKor.Text = "label";
            // 
            // frmKupacPoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 508);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtUkCena);
            this.Controls.Add(this.numBrMesta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAzuriraj);
            this.Controls.Add(this.btnObrisi);
            this.Controls.Add(this.btnNovaRez);
            this.Controls.Add(this.lstRez);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblKor);
            this.Name = "frmKupacPoc";
            this.Text = "frmKupacPoc";
            ((System.ComponentModel.ISupportInitialize)(this.numBrMesta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUkCena;
        private System.Windows.Forms.NumericUpDown numBrMesta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAzuriraj;
        private System.Windows.Forms.Button btnObrisi;
        private System.Windows.Forms.Button btnNovaRez;
        private System.Windows.Forms.ListBox lstRez;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblKor;
    }
}