﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prvi_projekat
{
    [Serializable]
    class Projekcija
    {
        private int id, cenaKarte;
        private DateTime datumProj;
        private Sala sala;
        private DateTime vremePocetka;
        private Film film;
        private int slobodnoMesta;

        public Projekcija(int id, int cenaKarte, DateTime datumProj, Sala sala, DateTime vremePocetka, Film film)
        {
            SlobodnoMesta = sala.BrSedista;
            this.Id = id;
            this.CenaKarte = cenaKarte;
            this.DatumProj = datumProj;
            this.Sala = sala;
            this.VremePocetka = vremePocetka;
            this.Film = film;
        }

        public int Id { get => id; set => id = value; }
        public int CenaKarte { get => cenaKarte; set => cenaKarte = value; }
        public DateTime DatumProj { get => datumProj; set => datumProj = value; }
        public DateTime VremePocetka { get => vremePocetka; set => vremePocetka = value; }
        public int SlobodnoMesta { get => slobodnoMesta; set => slobodnoMesta = value; }
        internal Sala Sala { get => sala; set => sala = value; }
        internal Film Film { get => film; set => film = value; }

        public override string ToString()
        {
            return $"{film.ToString()}; Broj sale: {sala.BrSale}; Cena karte: {cenaKarte}; Datum pocetka projekcije: {datumProj}; Vreme pocetka: {vremePocetka}; Broj slobodnih mesta: {slobodnoMesta}";
        }
    }
}
