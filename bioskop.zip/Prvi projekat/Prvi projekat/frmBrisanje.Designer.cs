﻿namespace Prvi_projekat
{
    partial class frmBrisanje
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnObrisiKorisnika = new System.Windows.Forms.Button();
            this.cbKorisnik = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnObrisiProj = new System.Windows.Forms.Button();
            this.cbProj = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnObrisiSalu = new System.Windows.Forms.Button();
            this.cbSala = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnObrisiRezervaciju = new System.Windows.Forms.Button();
            this.cbRezervacija = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnObrisiFilm = new System.Windows.Forms.Button();
            this.cbFilm = new System.Windows.Forms.ComboBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnObrisiKorisnika
            // 
            this.btnObrisiKorisnika.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnObrisiKorisnika.Location = new System.Drawing.Point(520, 247);
            this.btnObrisiKorisnika.Name = "btnObrisiKorisnika";
            this.btnObrisiKorisnika.Size = new System.Drawing.Size(75, 28);
            this.btnObrisiKorisnika.TabIndex = 182;
            this.btnObrisiKorisnika.Text = "Obrisi";
            this.btnObrisiKorisnika.UseVisualStyleBackColor = true;
            this.btnObrisiKorisnika.Click += new System.EventHandler(this.btnObrisiKorisnika_Click);
            // 
            // cbKorisnik
            // 
            this.cbKorisnik.FormattingEnabled = true;
            this.cbKorisnik.Location = new System.Drawing.Point(110, 252);
            this.cbKorisnik.Name = "cbKorisnik";
            this.cbKorisnik.Size = new System.Drawing.Size(404, 21);
            this.cbKorisnik.TabIndex = 181;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(45, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 16);
            this.label5.TabIndex = 180;
            this.label5.Text = "Korisnik:";
            // 
            // btnObrisiProj
            // 
            this.btnObrisiProj.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnObrisiProj.Location = new System.Drawing.Point(520, 131);
            this.btnObrisiProj.Name = "btnObrisiProj";
            this.btnObrisiProj.Size = new System.Drawing.Size(75, 28);
            this.btnObrisiProj.TabIndex = 179;
            this.btnObrisiProj.Text = "Obrisi";
            this.btnObrisiProj.UseVisualStyleBackColor = true;
            this.btnObrisiProj.Click += new System.EventHandler(this.btnObrisiProj_Click);
            // 
            // cbProj
            // 
            this.cbProj.FormattingEnabled = true;
            this.cbProj.Location = new System.Drawing.Point(110, 136);
            this.cbProj.Name = "cbProj";
            this.cbProj.Size = new System.Drawing.Size(404, 21);
            this.cbProj.TabIndex = 178;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(32, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 177;
            this.label3.Text = "Projekcija:";
            // 
            // btnObrisiSalu
            // 
            this.btnObrisiSalu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnObrisiSalu.Location = new System.Drawing.Point(520, 170);
            this.btnObrisiSalu.Name = "btnObrisiSalu";
            this.btnObrisiSalu.Size = new System.Drawing.Size(75, 28);
            this.btnObrisiSalu.TabIndex = 176;
            this.btnObrisiSalu.Text = "Obrisi";
            this.btnObrisiSalu.UseVisualStyleBackColor = true;
            this.btnObrisiSalu.Click += new System.EventHandler(this.btnObrisiSalu_Click);
            // 
            // cbSala
            // 
            this.cbSala.FormattingEnabled = true;
            this.cbSala.Location = new System.Drawing.Point(110, 175);
            this.cbSala.Name = "cbSala";
            this.cbSala.Size = new System.Drawing.Size(404, 21);
            this.cbSala.TabIndex = 175;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(67, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 174;
            this.label2.Text = "Sala:";
            // 
            // btnObrisiRezervaciju
            // 
            this.btnObrisiRezervaciju.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnObrisiRezervaciju.Location = new System.Drawing.Point(520, 209);
            this.btnObrisiRezervaciju.Name = "btnObrisiRezervaciju";
            this.btnObrisiRezervaciju.Size = new System.Drawing.Size(75, 28);
            this.btnObrisiRezervaciju.TabIndex = 173;
            this.btnObrisiRezervaciju.Text = "Obrisi";
            this.btnObrisiRezervaciju.UseVisualStyleBackColor = true;
            this.btnObrisiRezervaciju.Click += new System.EventHandler(this.btnObrisiRezervaciju_Click);
            // 
            // cbRezervacija
            // 
            this.cbRezervacija.FormattingEnabled = true;
            this.cbRezervacija.Location = new System.Drawing.Point(110, 214);
            this.cbRezervacija.Name = "cbRezervacija";
            this.cbRezervacija.Size = new System.Drawing.Size(404, 21);
            this.cbRezervacija.TabIndex = 172;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 219);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 171;
            this.label1.Text = "Rezervacije:";
            // 
            // btnObrisiFilm
            // 
            this.btnObrisiFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnObrisiFilm.Location = new System.Drawing.Point(520, 89);
            this.btnObrisiFilm.Name = "btnObrisiFilm";
            this.btnObrisiFilm.Size = new System.Drawing.Size(75, 28);
            this.btnObrisiFilm.TabIndex = 170;
            this.btnObrisiFilm.Text = "Obrisi";
            this.btnObrisiFilm.UseVisualStyleBackColor = true;
            this.btnObrisiFilm.Click += new System.EventHandler(this.btnObrisiFilm_Click);
            // 
            // cbFilm
            // 
            this.cbFilm.FormattingEnabled = true;
            this.cbFilm.Location = new System.Drawing.Point(110, 94);
            this.cbFilm.Name = "cbFilm";
            this.cbFilm.Size = new System.Drawing.Size(404, 21);
            this.cbFilm.TabIndex = 169;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(67, 100);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(36, 16);
            this.label49.TabIndex = 168;
            this.label49.Text = "Film:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(175, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(294, 39);
            this.label4.TabIndex = 167;
            this.label4.Text = "Brisanje podataka";
            // 
            // frmBrisanje
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 352);
            this.Controls.Add(this.btnObrisiKorisnika);
            this.Controls.Add(this.cbKorisnik);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnObrisiProj);
            this.Controls.Add(this.cbProj);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnObrisiSalu);
            this.Controls.Add(this.cbSala);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnObrisiRezervaciju);
            this.Controls.Add(this.cbRezervacija);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnObrisiFilm);
            this.Controls.Add(this.cbFilm);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label4);
            this.Name = "frmBrisanje";
            this.Text = "frmBrisanje";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnObrisiKorisnika;
        private System.Windows.Forms.ComboBox cbKorisnik;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnObrisiProj;
        private System.Windows.Forms.ComboBox cbProj;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnObrisiSalu;
        private System.Windows.Forms.ComboBox cbSala;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnObrisiRezervaciju;
        private System.Windows.Forms.ComboBox cbRezervacija;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnObrisiFilm;
        private System.Windows.Forms.ComboBox cbFilm;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label4;
    }
}