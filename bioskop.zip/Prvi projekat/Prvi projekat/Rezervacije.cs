﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prvi_projekat
{
    [Serializable]
    class Rezervacije
    {
        private int idProj, idKupca, brMesta, ukCena;

        public Rezervacije(int idProj, int idKupca, int brMesta, int ukCena)
        {
            this.IdProj = idProj;
            this.IdKupca = idKupca;
            this.BrMesta = brMesta;
            this.UkCena = ukCena;
        }

        public int IdProj { get => idProj; set => idProj = value; }
        public int IdKupca { get => idKupca; set => idKupca = value; }
        public int BrMesta { get => brMesta; set => brMesta = value; }
        public int UkCena { get => ukCena; set => ukCena = value; }

        public override string ToString()
        {
            return $"ID proj: {idProj}; ID kupca: {idKupca}; Broj mesta: {brMesta}; Ukupna cena: {ukCena}";
        }
    }
}
