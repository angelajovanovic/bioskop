﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prvi_projekat
{
    public partial class frmKupac : Form
    {
        FileStream fs;
        BinaryFormatter bf = new BinaryFormatter();

        public delegate void izmenaListe();
        izmenaListe izmena;

        int idKor;
        List<Sala> sale;
        List<Film> filmovi;
        List<Projekcija> projekcije;
        List<Rezervacije> rezervacije;

        string fajlSale = "sale.bin";
        string fajlFilmovi = "filmovi.bin";
        string fajlProj = "projekcije.bin";
        string fajlRez = "rezervacije.bin";
        public frmKupac(int idKor)
        {
            InitializeComponent();
            this.idKor = idKor;

            dtPocDat.MinDate = DateTime.Today;
            dtKrajnjiDatum.MinDate = DateTime.Today;

            if (File.Exists(fajlSale))
            {
                fs = File.OpenRead(fajlSale);
                sale = bf.Deserialize(fs) as List<Sala>;
                fs.Close();
            }
            else
                sale = new List<Sala>();

            if (File.Exists(fajlFilmovi))
            {
                fs = File.OpenRead(fajlFilmovi);
                filmovi = bf.Deserialize(fs) as List<Film>;
                fs.Close();
            }
            else
                filmovi = new List<Film>();

            if (File.Exists(fajlProj))
            {
                fs = File.OpenRead(fajlProj);
                projekcije = bf.Deserialize(fs) as List<Projekcija>;
                fs.Close();
            }
            else
                projekcije = new List<Projekcija>();

            if (File.Exists(fajlRez))
            {
                fs = File.OpenRead(fajlRez);
                rezervacije = bf.Deserialize(fs) as List<Rezervacije>;
                fs.Close();
            }
            else
                rezervacije = new List<Rezervacije>();

            foreach (Sala sala in sale)
                cbSala.Items.Add(sala);
            foreach (Film film in filmovi)
                cbNaziv.Items.Add(film.Naziv);
        }

        private void btnPrikaziDostProj_Click(object sender, EventArgs e)
        {
            izmena = new izmenaListe(PromeniListu);
            izmena();
        }

        private void btnRezervisi_Click(object sender, EventArgs e)
        {
            if (numBrMesta.Value == 0 || lstRepertoar.SelectedItem == null || txtUkCena.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste izabrali ili uneli sve stavke za rezervaciju");
                return;
            }
            foreach (Projekcija proj in projekcije)
                if (proj.Id == (lstRepertoar.SelectedItem as Projekcija).Id)
                    if (int.Parse(numBrMesta.Value.ToString()) > proj.SlobodnoMesta)
                    {
                        MessageBox.Show("Nema dovoljno slobodnih mesta. Broj slobodnih mesta je " + proj.SlobodnoMesta);
                        return;
                    }
            rezervacije.Add(new Rezervacije((lstRepertoar.SelectedItem as Projekcija).Id, idKor, int.Parse(numBrMesta.Value.ToString()), int.Parse(txtUkCena.Text)));
            fs = File.OpenWrite(fajlRez);
            bf.Serialize(fs, rezervacije);
            fs.Close();

            frmKupacPoc kupacRez;
            foreach (Form forma in Application.OpenForms)
                if (forma.Name == "frmKupacPoc")
                {
                    kupacRez = forma as frmKupacPoc;
                    izmena = new izmenaListe(kupacRez.IzmeniListu);
                    izmena();
                }
            for (int i = 0; i < projekcije.Count; i++)
            {
                if (projekcije[i].Id == rezervacije[rezervacije.Count - 1].IdProj)
                {
                    projekcije[i].SlobodnoMesta -= rezervacije[rezervacije.Count - 1].BrMesta;
                }
            }
            fs = File.OpenWrite(fajlProj);
            bf.Serialize(fs, projekcije);
            fs.Close();

            izmena = new izmenaListe(PromeniListu);
            izmena();

            MessageBox.Show("Uspesno ste napravili rezervaciju!");
        }

        private void numBrMesta_ValueChanged(object sender, EventArgs e)
        {
            if (lstRepertoar.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali projekciju");
                numBrMesta.Value = 0;
                return;
            }
            txtUkCena.Text = ((lstRepertoar.SelectedItem as Projekcija).CenaKarte * numBrMesta.Value).ToString();
        }
        public void PromeniListu()
        {
            if (cbSala.SelectedItem == null || cbNaziv.SelectedItem == null)
            {
                MessageBox.Show("Niste odabrali salu ili film");
                return;
            }
            else if (dtPocDat.Value > dtKrajnjiDatum.Value)
            {
                MessageBox.Show("Pocetni datum ne sme biti veci od krajnjeg");
                return;
            }
            lstRepertoar.Items.Clear();
            foreach (Projekcija proj in projekcije)
            {
                if (proj.DatumProj > dtPocDat.Value && proj.DatumProj < dtKrajnjiDatum.Value && proj.Sala.Id == (cbSala.SelectedItem as Sala).Id && proj.Film.Naziv == cbNaziv.SelectedItem.ToString())
                {
                    lstRepertoar.Items.Add(proj);
                }
            }
            if (lstRepertoar.Items.Count == 0)
            {
                MessageBox.Show("Nema dostupnih projekcija za izabrane vrednosti");
            }
        }

        private void frmKupac_Load(object sender, EventArgs e)
        {

        }
    }
}
