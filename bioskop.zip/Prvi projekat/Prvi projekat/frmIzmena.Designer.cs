﻿namespace Prvi_projekat
{
    partial class frmIzmena
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtVrPoc = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtDatumRodjKor = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbPolKor = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTelKor = new System.Windows.Forms.TextBox();
            this.txtPrezKor = new System.Windows.Forms.TextBox();
            this.txtImeKor = new System.Windows.Forms.TextBox();
            this.cbKorisnik = new System.Windows.Forms.ComboBox();
            this.cbRez = new System.Windows.Forms.ComboBox();
            this.cbSala = new System.Windows.Forms.ComboBox();
            this.cbProjekcija = new System.Windows.Forms.ComboBox();
            this.cbFilm = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnIzmeniKorisnika = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtLoz = new System.Windows.Forms.TextBox();
            this.txtKorIme = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.cbIdKupca = new System.Windows.Forms.ComboBox();
            this.cbIdProj = new System.Windows.Forms.ComboBox();
            this.btnIzmeniRez = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtUkCena = new System.Windows.Forms.TextBox();
            this.txtBrMesta = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.btnIzmeniSalu = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.txtBrSedista = new System.Windows.Forms.TextBox();
            this.txtBrSale = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.dtProj = new System.Windows.Forms.DateTimePicker();
            this.cbProjSala = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.cbProjFilm = new System.Windows.Forms.ComboBox();
            this.btnMenjajProj = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.txtCena = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.btnIzmeniFilm = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txtGranica = new System.Windows.Forms.TextBox();
            this.txtDuzina = new System.Windows.Forms.TextBox();
            this.txtZanr = new System.Windows.Forms.TextBox();
            this.txtNaziv = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dtVrPoc
            // 
            this.dtVrPoc.Location = new System.Drawing.Point(674, 187);
            this.dtVrPoc.Name = "dtVrPoc";
            this.dtVrPoc.Size = new System.Drawing.Size(130, 20);
            this.dtVrPoc.TabIndex = 228;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(47, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(286, 13);
            this.label7.TabIndex = 227;
            this.label7.Text = "*Podatci ce biti sacuvani nakon zatvaranja forme";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(305, 470);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 13);
            this.label6.TabIndex = 226;
            this.label6.Text = "Ime";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(682, 471);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 225;
            this.label1.Text = "Datum rodjenja";
            // 
            // dtDatumRodjKor
            // 
            this.dtDatumRodjKor.Location = new System.Drawing.Point(685, 448);
            this.dtDatumRodjKor.Name = "dtDatumRodjKor";
            this.dtDatumRodjKor.Size = new System.Drawing.Size(200, 20);
            this.dtDatumRodjKor.TabIndex = 224;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(589, 471);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 223;
            this.label5.Text = "Telefon";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(497, 471);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 13);
            this.label3.TabIndex = 222;
            this.label3.Text = "Pol";
            // 
            // cbPolKor
            // 
            this.cbPolKor.FormattingEnabled = true;
            this.cbPolKor.Items.AddRange(new object[] {
            "muski",
            "zenski"});
            this.cbPolKor.Location = new System.Drawing.Point(500, 447);
            this.cbPolKor.Name = "cbPolKor";
            this.cbPolKor.Size = new System.Drawing.Size(75, 21);
            this.cbPolKor.TabIndex = 221;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(405, 470);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 220;
            this.label2.Text = "Prezime";
            // 
            // txtTelKor
            // 
            this.txtTelKor.Location = new System.Drawing.Point(592, 448);
            this.txtTelKor.Name = "txtTelKor";
            this.txtTelKor.Size = new System.Drawing.Size(75, 20);
            this.txtTelKor.TabIndex = 219;
            // 
            // txtPrezKor
            // 
            this.txtPrezKor.Location = new System.Drawing.Point(408, 447);
            this.txtPrezKor.Name = "txtPrezKor";
            this.txtPrezKor.Size = new System.Drawing.Size(86, 20);
            this.txtPrezKor.TabIndex = 218;
            // 
            // txtImeKor
            // 
            this.txtImeKor.Location = new System.Drawing.Point(305, 447);
            this.txtImeKor.Name = "txtImeKor";
            this.txtImeKor.Size = new System.Drawing.Size(97, 20);
            this.txtImeKor.TabIndex = 217;
            // 
            // cbKorisnik
            // 
            this.cbKorisnik.FormattingEnabled = true;
            this.cbKorisnik.Location = new System.Drawing.Point(140, 409);
            this.cbKorisnik.Name = "cbKorisnik";
            this.cbKorisnik.Size = new System.Drawing.Size(745, 21);
            this.cbKorisnik.TabIndex = 216;
            this.cbKorisnik.SelectedIndexChanged += new System.EventHandler(this.cbKorisnik_SelectedIndexChanged);
            // 
            // cbRez
            // 
            this.cbRez.FormattingEnabled = true;
            this.cbRez.Location = new System.Drawing.Point(527, 283);
            this.cbRez.Name = "cbRez";
            this.cbRez.Size = new System.Drawing.Size(358, 21);
            this.cbRez.TabIndex = 215;
            this.cbRez.SelectedIndexChanged += new System.EventHandler(this.cbRez_SelectedIndexChanged);
            // 
            // cbSala
            // 
            this.cbSala.FormattingEnabled = true;
            this.cbSala.Location = new System.Drawing.Point(129, 278);
            this.cbSala.Name = "cbSala";
            this.cbSala.Size = new System.Drawing.Size(241, 21);
            this.cbSala.TabIndex = 214;
            this.cbSala.SelectedIndexChanged += new System.EventHandler(this.cbSala_SelectedIndexChanged_1);
            // 
            // cbProjekcija
            // 
            this.cbProjekcija.FormattingEnabled = true;
            this.cbProjekcija.Location = new System.Drawing.Point(527, 109);
            this.cbProjekcija.Name = "cbProjekcija";
            this.cbProjekcija.Size = new System.Drawing.Size(358, 21);
            this.cbProjekcija.TabIndex = 213;
            this.cbProjekcija.SelectedIndexChanged += new System.EventHandler(this.cbProjekcija_SelectedIndexChanged);
            // 
            // cbFilm
            // 
            this.cbFilm.FormattingEnabled = true;
            this.cbFilm.Location = new System.Drawing.Point(128, 109);
            this.cbFilm.Name = "cbFilm";
            this.cbFilm.Size = new System.Drawing.Size(242, 21);
            this.cbFilm.TabIndex = 212;
            this.cbFilm.SelectedIndexChanged += new System.EventHandler(this.cbFilm_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(366, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(282, 39);
            this.label4.TabIndex = 211;
            this.label4.Text = "Izmena podataka";
            // 
            // btnIzmeniKorisnika
            // 
            this.btnIzmeniKorisnika.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzmeniKorisnika.Location = new System.Drawing.Point(129, 487);
            this.btnIzmeniKorisnika.Name = "btnIzmeniKorisnika";
            this.btnIzmeniKorisnika.Size = new System.Drawing.Size(756, 28);
            this.btnIzmeniKorisnika.TabIndex = 210;
            this.btnIzmeniKorisnika.Text = "Izmeni";
            this.btnIzmeniKorisnika.UseVisualStyleBackColor = true;
            this.btnIzmeniKorisnika.Click += new System.EventHandler(this.btnIzmeniKorisnika_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(221, 470);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(44, 13);
            this.label28.TabIndex = 209;
            this.label28.Text = "Lozinka";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(140, 470);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(75, 13);
            this.label29.TabIndex = 208;
            this.label29.Text = "Korisnicko ime";
            // 
            // txtLoz
            // 
            this.txtLoz.Location = new System.Drawing.Point(224, 447);
            this.txtLoz.Name = "txtLoz";
            this.txtLoz.Size = new System.Drawing.Size(75, 20);
            this.txtLoz.TabIndex = 207;
            // 
            // txtKorIme
            // 
            this.txtKorIme.Location = new System.Drawing.Point(140, 447);
            this.txtKorIme.Name = "txtKorIme";
            this.txtKorIme.Size = new System.Drawing.Size(75, 20);
            this.txtKorIme.TabIndex = 206;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(84, 410);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(58, 16);
            this.label30.TabIndex = 205;
            this.label30.Text = "Korisnik:";
            // 
            // cbIdKupca
            // 
            this.cbIdKupca.FormattingEnabled = true;
            this.cbIdKupca.Location = new System.Drawing.Point(605, 314);
            this.cbIdKupca.Name = "cbIdKupca";
            this.cbIdKupca.Size = new System.Drawing.Size(72, 21);
            this.cbIdKupca.TabIndex = 204;
            // 
            // cbIdProj
            // 
            this.cbIdProj.FormattingEnabled = true;
            this.cbIdProj.Location = new System.Drawing.Point(527, 314);
            this.cbIdProj.Name = "cbIdProj";
            this.cbIdProj.Size = new System.Drawing.Size(72, 21);
            this.cbIdProj.TabIndex = 203;
            // 
            // btnIzmeniRez
            // 
            this.btnIzmeniRez.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzmeniRez.Location = new System.Drawing.Point(527, 354);
            this.btnIzmeniRez.Name = "btnIzmeniRez";
            this.btnIzmeniRez.Size = new System.Drawing.Size(358, 28);
            this.btnIzmeniRez.TabIndex = 202;
            this.btnIzmeniRez.Text = "Izmeni";
            this.btnIzmeniRez.UseVisualStyleBackColor = true;
            this.btnIzmeniRez.Click += new System.EventHandler(this.btnIzmeniRez_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(807, 338);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(72, 13);
            this.label31.TabIndex = 201;
            this.label31.Text = "Ukupna cena";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(702, 338);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(56, 13);
            this.label32.TabIndex = 200;
            this.label32.Text = "Broj mesta";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(602, 338);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(51, 13);
            this.label33.TabIndex = 199;
            this.label33.Text = "ID kupca";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(524, 338);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(66, 13);
            this.label34.TabIndex = 198;
            this.label34.Text = "ID projekcije";
            // 
            // txtUkCena
            // 
            this.txtUkCena.Location = new System.Drawing.Point(810, 315);
            this.txtUkCena.Name = "txtUkCena";
            this.txtUkCena.ReadOnly = true;
            this.txtUkCena.Size = new System.Drawing.Size(75, 20);
            this.txtUkCena.TabIndex = 197;
            // 
            // txtBrMesta
            // 
            this.txtBrMesta.Location = new System.Drawing.Point(705, 312);
            this.txtBrMesta.Name = "txtBrMesta";
            this.txtBrMesta.Size = new System.Drawing.Size(75, 20);
            this.txtBrMesta.TabIndex = 196;
            this.txtBrMesta.TextChanged += new System.EventHandler(this.txtBrMesta_TextChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(438, 283);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(83, 16);
            this.label35.TabIndex = 195;
            this.label35.Text = "Rezervacije:";
            // 
            // btnIzmeniSalu
            // 
            this.btnIzmeniSalu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzmeniSalu.Location = new System.Drawing.Point(128, 345);
            this.btnIzmeniSalu.Name = "btnIzmeniSalu";
            this.btnIzmeniSalu.Size = new System.Drawing.Size(242, 28);
            this.btnIzmeniSalu.TabIndex = 194;
            this.btnIzmeniSalu.Text = "Izmeni";
            this.btnIzmeniSalu.UseVisualStyleBackColor = true;
            this.btnIzmeniSalu.Click += new System.EventHandler(this.btnIzmeniSalu_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(258, 329);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(61, 13);
            this.label36.TabIndex = 193;
            this.label36.Text = "Broj sedista";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(126, 329);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(47, 13);
            this.label37.TabIndex = 192;
            this.label37.Text = "Broj sale";
            // 
            // txtBrSedista
            // 
            this.txtBrSedista.Location = new System.Drawing.Point(260, 306);
            this.txtBrSedista.Name = "txtBrSedista";
            this.txtBrSedista.Size = new System.Drawing.Size(110, 20);
            this.txtBrSedista.TabIndex = 191;
            // 
            // txtBrSale
            // 
            this.txtBrSale.Location = new System.Drawing.Point(129, 306);
            this.txtBrSale.Name = "txtBrSale";
            this.txtBrSale.Size = new System.Drawing.Size(109, 20);
            this.txtBrSale.TabIndex = 190;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(84, 278);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(39, 16);
            this.label38.TabIndex = 189;
            this.label38.Text = "Sala:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(524, 210);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(86, 13);
            this.label39.TabIndex = 188;
            this.label39.Text = "Datum projekcije";
            // 
            // dtProj
            // 
            this.dtProj.Location = new System.Drawing.Point(527, 187);
            this.dtProj.Name = "dtProj";
            this.dtProj.Size = new System.Drawing.Size(130, 20);
            this.dtProj.TabIndex = 187;
            // 
            // cbProjSala
            // 
            this.cbProjSala.FormattingEnabled = true;
            this.cbProjSala.Location = new System.Drawing.Point(730, 136);
            this.cbProjSala.Name = "cbProjSala";
            this.cbProjSala.Size = new System.Drawing.Size(155, 21);
            this.cbProjSala.TabIndex = 186;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(727, 160);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(28, 13);
            this.label40.TabIndex = 185;
            this.label40.Text = "Sala";
            // 
            // cbProjFilm
            // 
            this.cbProjFilm.FormattingEnabled = true;
            this.cbProjFilm.Location = new System.Drawing.Point(527, 136);
            this.cbProjFilm.Name = "cbProjFilm";
            this.cbProjFilm.Size = new System.Drawing.Size(155, 21);
            this.cbProjFilm.TabIndex = 184;
            // 
            // btnMenjajProj
            // 
            this.btnMenjajProj.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenjajProj.Location = new System.Drawing.Point(527, 226);
            this.btnMenjajProj.Name = "btnMenjajProj";
            this.btnMenjajProj.Size = new System.Drawing.Size(358, 28);
            this.btnMenjajProj.TabIndex = 183;
            this.btnMenjajProj.Text = "Izmeni";
            this.btnMenjajProj.UseVisualStyleBackColor = true;
            this.btnMenjajProj.Click += new System.EventHandler(this.btnMenjajProj_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(807, 210);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(59, 13);
            this.label41.TabIndex = 182;
            this.label41.Text = "Cena karte";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(671, 210);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(79, 13);
            this.label42.TabIndex = 181;
            this.label42.Text = "Vreme pocetka";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(524, 163);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(25, 13);
            this.label43.TabIndex = 180;
            this.label43.Text = "Film";
            // 
            // txtCena
            // 
            this.txtCena.Location = new System.Drawing.Point(810, 187);
            this.txtCena.Name = "txtCena";
            this.txtCena.Size = new System.Drawing.Size(75, 20);
            this.txtCena.TabIndex = 179;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(450, 110);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(71, 16);
            this.label44.TabIndex = 178;
            this.label44.Text = "Projekcija:";
            // 
            // btnIzmeniFilm
            // 
            this.btnIzmeniFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzmeniFilm.Location = new System.Drawing.Point(127, 226);
            this.btnIzmeniFilm.Name = "btnIzmeniFilm";
            this.btnIzmeniFilm.Size = new System.Drawing.Size(243, 28);
            this.btnIzmeniFilm.TabIndex = 177;
            this.btnIzmeniFilm.Text = "Izmeni";
            this.btnIzmeniFilm.UseVisualStyleBackColor = true;
            this.btnIzmeniFilm.Click += new System.EventHandler(this.btnIzmeniFilm_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(263, 210);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(37, 13);
            this.label45.TabIndex = 176;
            this.label45.Text = "Uzrast";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(125, 210);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(48, 13);
            this.label46.TabIndex = 175;
            this.label46.Text = "Trajanje:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(258, 163);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(29, 13);
            this.label47.TabIndex = 174;
            this.label47.Text = "Zanr";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(126, 163);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(34, 13);
            this.label48.TabIndex = 173;
            this.label48.Text = "Naziv";
            // 
            // txtGranica
            // 
            this.txtGranica.Location = new System.Drawing.Point(260, 187);
            this.txtGranica.Name = "txtGranica";
            this.txtGranica.Size = new System.Drawing.Size(110, 20);
            this.txtGranica.TabIndex = 172;
            // 
            // txtDuzina
            // 
            this.txtDuzina.Location = new System.Drawing.Point(127, 187);
            this.txtDuzina.Name = "txtDuzina";
            this.txtDuzina.Size = new System.Drawing.Size(111, 20);
            this.txtDuzina.TabIndex = 171;
            // 
            // txtZanr
            // 
            this.txtZanr.Location = new System.Drawing.Point(260, 140);
            this.txtZanr.Name = "txtZanr";
            this.txtZanr.Size = new System.Drawing.Size(110, 20);
            this.txtZanr.TabIndex = 170;
            // 
            // txtNaziv
            // 
            this.txtNaziv.Location = new System.Drawing.Point(127, 140);
            this.txtNaziv.Name = "txtNaziv";
            this.txtNaziv.Size = new System.Drawing.Size(111, 20);
            this.txtNaziv.TabIndex = 169;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(87, 110);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(36, 16);
            this.label49.TabIndex = 168;
            this.label49.Text = "Film:";
            // 
            // frmIzmena
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 539);
            this.Controls.Add(this.dtVrPoc);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtDatumRodjKor);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbPolKor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTelKor);
            this.Controls.Add(this.txtPrezKor);
            this.Controls.Add(this.txtImeKor);
            this.Controls.Add(this.cbKorisnik);
            this.Controls.Add(this.cbRez);
            this.Controls.Add(this.cbSala);
            this.Controls.Add(this.cbProjekcija);
            this.Controls.Add(this.cbFilm);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnIzmeniKorisnika);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.txtLoz);
            this.Controls.Add(this.txtKorIme);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.cbIdKupca);
            this.Controls.Add(this.cbIdProj);
            this.Controls.Add(this.btnIzmeniRez);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.txtUkCena);
            this.Controls.Add(this.txtBrMesta);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.btnIzmeniSalu);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.txtBrSedista);
            this.Controls.Add(this.txtBrSale);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.dtProj);
            this.Controls.Add(this.cbProjSala);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.cbProjFilm);
            this.Controls.Add(this.btnMenjajProj);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.txtCena);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.btnIzmeniFilm);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.txtGranica);
            this.Controls.Add(this.txtDuzina);
            this.Controls.Add(this.txtZanr);
            this.Controls.Add(this.txtNaziv);
            this.Controls.Add(this.label49);
            this.Name = "frmIzmena";
            this.Text = "frmIzmena";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmIzmena_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtVrPoc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtDatumRodjKor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbPolKor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTelKor;
        private System.Windows.Forms.TextBox txtPrezKor;
        private System.Windows.Forms.TextBox txtImeKor;
        private System.Windows.Forms.ComboBox cbKorisnik;
        private System.Windows.Forms.ComboBox cbRez;
        private System.Windows.Forms.ComboBox cbSala;
        private System.Windows.Forms.ComboBox cbProjekcija;
        private System.Windows.Forms.ComboBox cbFilm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnIzmeniKorisnika;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtLoz;
        private System.Windows.Forms.TextBox txtKorIme;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox cbIdKupca;
        private System.Windows.Forms.ComboBox cbIdProj;
        private System.Windows.Forms.Button btnIzmeniRez;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtUkCena;
        private System.Windows.Forms.TextBox txtBrMesta;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button btnIzmeniSalu;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtBrSedista;
        private System.Windows.Forms.TextBox txtBrSale;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.DateTimePicker dtProj;
        private System.Windows.Forms.ComboBox cbProjSala;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox cbProjFilm;
        private System.Windows.Forms.Button btnMenjajProj;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtCena;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button btnIzmeniFilm;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtGranica;
        private System.Windows.Forms.TextBox txtDuzina;
        private System.Windows.Forms.TextBox txtZanr;
        private System.Windows.Forms.TextBox txtNaziv;
        private System.Windows.Forms.Label label49;
    }
}