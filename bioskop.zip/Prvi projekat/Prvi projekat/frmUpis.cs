﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prvi_projekat
{
    public partial class frmUpis : Form
    {
        FileStream fs;
        BinaryFormatter bf = new BinaryFormatter();

        List<Kupac> kupci;
        List<Film> filmovi;
        List<Sala> sale;
        List<Projekcija> projekcije;
        List<Rezervacije> rezervacije;

        string fajlFilmovi = "filmovi.bin";
        string fajlKupci = "kupci.bin";
        string fajlSale = "sale.bin";
        string fajlProj = "projekcije.bin";
        string fajlRez = "rezervacije.bin";
        public frmUpis()
        {
            InitializeComponent();
            filmovi = new List<Film>();
            sale = new List<Sala>();
            projekcije = new List<Projekcija>();
            rezervacije = new List<Rezervacije>();

            dtUpisProjDat.MinDate = DateTime.Today;

            if (File.Exists(fajlKupci))
            {
                fs = File.OpenRead(fajlKupci);
                kupci = bf.Deserialize(fs) as List<Kupac>;
                fs.Close();
            }
            else
                kupci = new List<Kupac>();

            foreach (Kupac k in kupci)
                cbUpisRezIDkupca.Items.Add(k.Id);

            if (File.Exists(fajlFilmovi))
            {
                fs = File.OpenRead(fajlFilmovi);
                filmovi = bf.Deserialize(fs) as List<Film>;

                fs.Close();
                foreach (Film film in filmovi)
                    cbUpisProjFilm.Items.Add(film);
            }
            if (File.Exists(fajlSale))
            {
                fs = File.OpenRead(fajlSale);
                sale = bf.Deserialize(fs) as List<Sala>;

                fs.Close();
                foreach (Sala sala in sale)
                    cbUpisProjSala.Items.Add(sala);
            }
            if (File.Exists(fajlProj))
            {
                fs = File.OpenRead(fajlProj);
                projekcije = bf.Deserialize(fs) as List<Projekcija>;

                fs.Close();
                foreach (Projekcija proj in projekcije)
                    cbUpisRezIDproj.Items.Add(proj.Id);
            }
            if (File.Exists(fajlRez))
            {
                fs = File.OpenRead(fajlRez);
                rezervacije = bf.Deserialize(fs) as List<Rezervacije>;

                fs.Close();
            }
        }

        private void btnDodajFilm_Click(object sender, EventArgs e)
        {
            int duzina, godine;
            if (txtUpisFlmNaziv.Text.Trim().Length == 0 || txtUpisFlmZanr.Text.Trim().Length == 0 || txtUpisFlmDuz.Text.Trim().Length == 0 || txtUpisFlmGodine.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste uneli sve informacije za film");
                return;
            }
            else if (!int.TryParse(txtUpisFlmDuz.Text, out duzina) || !int.TryParse(txtUpisFlmGodine.Text, out godine))
            {
                MessageBox.Show("Niste uneli broj za granicu godina ili duzinu filma");
                return;
            }
            filmovi.Add(new Film(filmovi.Count, duzina, godine, txtUpisFlmNaziv.Text, txtUpisFlmZanr.Text));
            cbUpisProjFilm.Items.Add(filmovi[filmovi.Count - 1]);

            fs = File.OpenWrite(fajlFilmovi);
            bf.Serialize(fs, filmovi);

            fs.Close();

            MessageBox.Show("Uspesno ste dodali film u bazu");
        }

        private void btnDodajSalu_Click(object sender, EventArgs e)
        {
            int brsale, brsed;
            if (txtUpisBrSale.Text.Trim().Length == 0 || txtUpisBrSed.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste uneli sve informacije za salu");
                return;
            }
            else if (!int.TryParse(txtUpisBrSale.Text, out brsale) || !int.TryParse(txtUpisBrSed.Text, out brsed))
            {
                MessageBox.Show("Niste uneli broj za broj sale ili broj sedista");
                return;
            }
            foreach (Sala sala in sale)
                if (brsale == sala.BrSale)
                {
                    MessageBox.Show("Sala vec postoji");
                    return;
                }
            sale.Add(new Sala(sale.Count, brsale, brsed));
            cbUpisProjSala.Items.Add(sale[sale.Count - 1]);

            fs = File.OpenWrite(fajlSale);
            bf.Serialize(fs, sale);

            fs.Close();

            MessageBox.Show("Uspesno ste dodali salu u bazu");
        }

        private void btnDodajProj_Click(object sender, EventArgs e)
        {
            int cena;
            if (cbUpisProjFilm.SelectedItem == null || cbUpisProjSala.SelectedItem == null || txtUpisProjCena.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste uneli sve informacije za projekciju");
                return;
            }
            else if (!int.TryParse(txtUpisProjCena.Text, out cena))
            {
                MessageBox.Show("Niste uneli broj za cenu karte");
                return;
            }
            projekcije.Add(new Projekcija(projekcije.Count, cena, dtUpisProjDat.Value, cbUpisProjSala.SelectedItem as Sala, dtVrPoc.Value, cbUpisProjFilm.SelectedItem as Film));
            cbUpisRezIDproj.Items.Add(projekcije[projekcije.Count - 1].Id);

            fs = File.OpenWrite(fajlProj);
            bf.Serialize(fs, projekcije);

            fs.Close();

            MessageBox.Show("Uspesno ste dodali projekciju u bazu");
        }

        private void btnUpisDodajRezervaciju_Click(object sender, EventArgs e)
        {
            int brMesta;
            if (cbUpisRezIDkupca.SelectedItem == null || cbUpisRezIDproj.SelectedItem == null || txtUpisRezBrMesta.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste uneli sve informacije za projekciju");
                return;
            }
            else if (!int.TryParse(txtUpisRezBrMesta.Text, out brMesta))
            {
                MessageBox.Show("Niste uneli broj za broj mesta");
                return;
            }
            foreach (Projekcija proj in projekcije)
                if (proj.Id == (int)cbUpisRezIDproj.SelectedItem)
                {
                    if (proj.SlobodnoMesta < brMesta)
                    {
                        MessageBox.Show("Nema dovoljno slobodnih mesta u sali. Broj slobodnih mesta je " + proj.SlobodnoMesta);
                        return;
                    }
                    break;
                }

            rezervacije.Add(new Rezervacije((int)cbUpisRezIDproj.SelectedItem, (int)cbUpisRezIDkupca.SelectedItem, brMesta, int.Parse(txtUpisRezUkCena.Text)));

            fs = File.OpenWrite(fajlRez);
            bf.Serialize(fs, rezervacije);

            fs.Close();

            for (int i = 0; i < projekcije.Count; i++)
            {
                if ((int)cbUpisRezIDproj.SelectedItem == projekcije[i].Id)
                {
                    projekcije[i].SlobodnoMesta -= brMesta;
                }
            }
            fs = File.OpenWrite(fajlProj);
            bf.Serialize(fs, projekcije);
            fs.Close();

            MessageBox.Show("Uspesno ste dodali rezervaciju u bazu");
        }

        private void btnUpisDodajKorisnika_Click(object sender, EventArgs e)
        {
            if (txtUpisKorKorime.Text.Trim().Length == 0 || txtUpisKorLoz.Text.Trim().Length == 0 || txtImeKor.Text.Trim().Length == 0 || txtPrezKor.Text.Trim().Length == 0 || cbPolKor.SelectedItem == null || txtTelKor.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste uneli sve informacije za korisnika");
                return;
            }
            kupci.Add(new Kupac(kupci.Count, txtUpisKorKorime.Text, txtUpisKorLoz.Text, txtImeKor.Text, txtPrezKor.Text, cbPolKor.SelectedItem.ToString(), txtTelKor.Text, dtDatumRodjKor.Value));

            fs = File.OpenWrite(fajlKupci);
            bf.Serialize(fs, kupci);

            fs.Close();

            cbUpisRezIDkupca.Items.Add(kupci[kupci.Count - 1].Id);

            MessageBox.Show("Uspesno ste dodali korisnika u bazu");
        }

        private void txtUpisRezBrMesta_TextChanged(object sender, EventArgs e)
        {
            int brMesta;
            if (!int.TryParse(txtUpisRezBrMesta.Text, out brMesta))
                return;
            if (cbUpisRezIDproj.SelectedItem == null)
                return;
            foreach (Projekcija proj in projekcije)
                if (proj.Id == (int)cbUpisRezIDproj.SelectedItem)
                {
                    txtUpisRezUkCena.Text = (proj.CenaKarte * brMesta).ToString();
                    break;
                }
        }
    }
}
