﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prvi_projekat
{
    public partial class frmBrisanje : Form
    {
        FileStream fs;
        BinaryFormatter bf = new BinaryFormatter();

        List<Kupac> kupci;
        List<Film> filmovi;
        List<Sala> sale;
        List<Projekcija> projekcije;
        List<Rezervacije> rezervacije;

        string fajlFilmovi = "filmovi.bin";
        string fajlKupci = "kupci.bin";
        string fajlSale = "sale.bin";
        string fajlProj = "projekcije.bin";
        string fajlRez = "rezervacije.bin";
        public frmBrisanje()
        {
            InitializeComponent();
            filmovi = new List<Film>();
            sale = new List<Sala>();
            projekcije = new List<Projekcija>();
            rezervacije = new List<Rezervacije>();

            if (File.Exists(fajlKupci))
            {
                fs = File.OpenRead(fajlKupci);
                kupci = bf.Deserialize(fs) as List<Kupac>;
                fs.Close();
            }
            else
                kupci = new List<Kupac>();


            if (File.Exists(fajlFilmovi))
            {
                fs = File.OpenRead(fajlFilmovi);
                filmovi = bf.Deserialize(fs) as List<Film>;
                fs.Close();
            }
            if (File.Exists(fajlSale))
            {
                fs = File.OpenRead(fajlSale);
                sale = bf.Deserialize(fs) as List<Sala>;
                fs.Close();
            }
            if (File.Exists(fajlProj))
            {
                fs = File.OpenRead(fajlProj);
                projekcije = bf.Deserialize(fs) as List<Projekcija>;

                fs.Close();
            }
            if (File.Exists(fajlRez))
            {
                fs = File.OpenRead(fajlRez);
                rezervacije = bf.Deserialize(fs) as List<Rezervacije>;

                fs.Close();
            }

            foreach (Film film in filmovi)
                cbFilm.Items.Add(film);
            foreach (Projekcija proj in projekcije)
                cbProj.Items.Add(proj);
            foreach (Sala sala in sale)
                cbSala.Items.Add(sala);
            foreach (Rezervacije rez in rezervacije)
                cbRezervacija.Items.Add(rez);
            foreach (Kupac kupac in kupci)
                cbKorisnik.Items.Add(kupac);
        }

        private void btnObrisiFilm_Click(object sender, EventArgs e)
        {
            if (cbFilm.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali film");
                return;
            }
            foreach (Projekcija proj in projekcije)
                if (proj.Film.Id == (cbFilm.SelectedItem as Film).Id)
                {
                    MessageBox.Show("Ne mozete obrisati film posto postoji projekcija za njega");
                    return;
                }
            for (int i = 0; i < filmovi.Count; i++)
            {
                if (cbFilm.SelectedItem as Film == filmovi[i])
                {
                    filmovi.RemoveAt(i);

                    fs = File.OpenWrite(fajlFilmovi);
                    bf.Serialize(fs, filmovi);
                    fs.Close();

                    cbFilm.Items.Clear();
                    foreach (Film film in filmovi)
                        cbFilm.Items.Add(film);

                    MessageBox.Show("Uspesno ste obrisali film");
                    return;
                }
            }
        }

        private void btnObrisiProj_Click(object sender, EventArgs e)
        {
            if (cbProj.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali projekciju");
                return;
            }
            foreach (Rezervacije rez in rezervacije)
            {
                if (rez.IdProj == (cbProj.SelectedItem as Projekcija).Id)
                {
                    MessageBox.Show("Ne mozete obrisati projekciju posto postoji rezervacija za njega");
                    return;
                }
            }
            for (int i = 0; i < projekcije.Count; i++)
            {
                if (cbProj.SelectedItem as Projekcija == projekcije[i])
                {
                    projekcije.RemoveAt(i);

                    fs = File.OpenWrite(fajlProj);
                    bf.Serialize(fs, projekcije);
                    fs.Close();

                    cbProj.Items.Clear();
                    foreach (Projekcija proj in projekcije)
                        cbProj.Items.Add(proj);

                    MessageBox.Show("Uspesno ste obrisali projekciju");
                    return;
                }
            }
        }

        private void btnObrisiSalu_Click(object sender, EventArgs e)
        {
            if (cbSala.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali salu");
                return;
            }
            foreach (Projekcija proj in projekcije)
                if (proj.Sala.Id == (cbSala.SelectedItem as Sala).Id)
                {
                    MessageBox.Show("Ne mozete obrisati salu posto postoji projekcija za nju");
                    return;
                }
            for (int i = 0; i < sale.Count; i++)
            {
                if (cbSala.SelectedItem as Sala == sale[i])
                {
                    sale.RemoveAt(i);

                    fs = File.OpenWrite(fajlSale);
                    bf.Serialize(fs, sale);
                    fs.Close();

                    cbSala.Items.Clear();
                    foreach (Sala sala in sale)
                        cbSala.Items.Add(sala);

                    MessageBox.Show("Uspesno ste obrisali salu");
                    return;
                }
            }
        }

        private void btnObrisiRezervaciju_Click(object sender, EventArgs e)
        {
            if (cbRezervacija.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali rezervaciju");
                return;
            }
            for (int i = 0; i < rezervacije.Count; i++)
            {
                if (cbRezervacija.SelectedItem as Rezervacije == rezervacije[i])
                {
                    for (int j = 0; j < projekcije.Count; j++)
                    {
                        if (rezervacije[i].IdProj == projekcije[j].Id)
                        {
                            projekcije[j].SlobodnoMesta += rezervacije[i].BrMesta;
                        }
                    }
                    rezervacije.RemoveAt(i);

                    fs = File.OpenWrite(fajlRez);
                    bf.Serialize(fs, rezervacije);
                    fs.Close();

                    fs = File.OpenWrite(fajlProj);
                    bf.Serialize(fs, projekcije);
                    fs.Close();

                    cbProj.Items.Clear();
                    foreach (Projekcija proj in projekcije)
                        cbProj.Items.Add(proj);

                    cbRezervacija.Items.Clear();
                    foreach (Rezervacije rez in rezervacije)
                        cbRezervacija.Items.Add(rez);

                    MessageBox.Show("Uspesno ste obrisali rezervaciju");
                    return;
                }
            }
        }

        private void btnObrisiKorisnika_Click(object sender, EventArgs e)
        {
            if (cbKorisnik.SelectedItem == null)
            {
                MessageBox.Show("Niste izabrali korisnika");
                return;
            }
            foreach (Rezervacije rez in rezervacije)
                if (rez.IdKupca == (cbKorisnik.SelectedItem as Kupac).Id)
                {
                    MessageBox.Show("Ne mozete obrisati korisnika posto postoji rezervacija za njega");
                    return;
                }
            for (int i = 0; i < kupci.Count; i++)
            {
                if (cbKorisnik.SelectedItem as Kupac == kupci[i])
                {
                    kupci.RemoveAt(i);

                    fs = File.OpenWrite(fajlKupci);
                    bf.Serialize(fs, kupci);
                    fs.Close();

                    cbKorisnik.Items.Clear();
                    foreach (Kupac k in kupci)
                        cbKorisnik.Items.Add(k);

                    MessageBox.Show("Uspesno ste obrisali korisnika");
                    return;
                }
            }
        }
    }
}
