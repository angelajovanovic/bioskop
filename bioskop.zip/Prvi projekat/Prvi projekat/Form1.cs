﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prvi_projekat
{
    public partial class Form1 : Form
    {
        List<Kupac> kupci;
        Administrator admin;
        string fajlKupci = "kupci.bin";
        public Form1()
        {
            InitializeComponent();

            admin = new Administrator();
            if (File.Exists(fajlKupci))
            {
                FileStream fs = File.OpenRead(fajlKupci);
                BinaryFormatter bf = new BinaryFormatter();
                kupci = bf.Deserialize(fs) as List<Kupac>;

                fs.Close();
            }
            else
                kupci = new List<Kupac>();
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            long tel;
            if (txtRegKorIme.Text.Trim().Length == 0 || txtRegLoz.Text.Trim().Length == 0 || txtPotLoz.Text.Trim().Length == 0 || txtIme.Text.Trim().Length == 0 || txtPrez.Text.Trim().Length == 0 || txtTel.Text.Trim().Length == 0)
            {
                MessageBox.Show("Niste popunili sva polja!");
                return;
            }
            else if (!rbM.Checked && !rbZ.Checked)
            {
                MessageBox.Show("Neophodno je odabrati pol");
                return;
            }
            else if (!long.TryParse(txtTel.Text, out tel))
            {
                MessageBox.Show("Niste uneli broj telefona");
                return;
            }
            else if (txtRegLoz.Text != txtPotLoz.Text)
            {
                MessageBox.Show("Niste potvrdili lozinku!");
                return;
            }
            foreach (Kupac kupac in kupci)
            {
                if (kupac.KorIme == txtRegKorIme.Text.Trim())
                {
                    MessageBox.Show("Korisnicko ime je zauzeto");
                    return;
                }
            }
            string pol = "";
            if (rbM.Checked)
                pol = "muski";
            else if (rbZ.Checked)
                pol = "zenski";


            kupci.Add(new Kupac(kupci.Count, txtRegKorIme.Text, txtRegLoz.Text, txtIme.Text, txtPrez.Text, pol, txtTel.Text, dtDatRodj.Value.Date));

            FileStream fs = File.OpenWrite(fajlKupci);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, kupci);
            fs.Close();

            MessageBox.Show("Uspesno ste se registrovali!");
        }

        private void btnUloguj_Click(object sender, EventArgs e)
        {
            if (txtPrijKorIme.Text.Trim().Length == 0 || txtPrijLoz.Text.Trim().Length == 0)
            {
                MessageBox.Show("Neko od polja je prazno");
                return;
            }
            else if (!File.Exists(fajlKupci) && (txtPrijKorIme.Text != admin.KorIme || txtPrijLoz.Text != admin.Lozinka))
            {
                MessageBox.Show("Ne postoje registrovani korisnici");
                return;
            }



            if (txtPrijKorIme.Text == admin.KorIme && txtPrijLoz.Text == admin.Lozinka)
            {
                MessageBox.Show("Ulogovani ste kao administrator");
                frmAdmin admForma = new frmAdmin();
                admForma.Show();
            }
            else
            {
                FileStream fs = File.OpenWrite(fajlKupci);
                BinaryFormatter bf = new BinaryFormatter();

                if (kupci.Count > 0)
                    bf.Serialize(fs, kupci);
                fs.Close();
                fs = File.OpenRead(fajlKupci);
                kupci = bf.Deserialize(fs) as List<Kupac>;


                foreach (Kupac kupac in kupci)
                    if (txtPrijKorIme.Text == kupac.KorIme && txtPrijLoz.Text == kupac.Lozinka)
                    {
                        MessageBox.Show("Ulogovani ste se kao kupac");
                        frmKupacPoc kupacForma = new frmKupacPoc(kupac.Id);
                        kupacForma.Show();
                        fs.Close();
                        return;
                    }
                MessageBox.Show("Pogresno korisnicko ime ili lozinka");
                fs.Close();
            }
        }
    }
}
